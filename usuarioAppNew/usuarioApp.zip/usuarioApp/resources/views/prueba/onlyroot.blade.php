@extends('layouts.app')

@section('content')
<h1>PRUEBA ROOT</h1>
@endsection
