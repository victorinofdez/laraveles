@extends('layouts.app')

@section('content')
<h1>PRUEBA</h1>
@endsection
