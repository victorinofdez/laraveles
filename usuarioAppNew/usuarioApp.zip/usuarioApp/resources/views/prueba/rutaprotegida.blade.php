@extends('layouts.app')

@section('content')
<h1>PRUEBA DE RUTA PROTEGIDA</h1>
@endsection
