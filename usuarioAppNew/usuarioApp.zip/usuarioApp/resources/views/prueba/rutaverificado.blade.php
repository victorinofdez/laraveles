@extends('layouts.app')

@section('content')
<h1>PRUEBA VERIFIACADA</h1>
@endsection
