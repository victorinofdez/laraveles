<?php

use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes(['verify' => true]);

Route::get('/home', [\App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('rutaconmiddleware', [\App\Http\Controllers\PruebaController::class, 'ruta'])->middleware('prueba');

Route::get('rcm', [\App\Http\Controllers\PruebaController::class, 'ruta']);
Route::get('rutaprotegida', [\App\Http\Controllers\PruebaController::class, 'rutaProtegida']);
Route::get('rutaprotegida2', [\App\Http\Controllers\PruebaController::class, 'rutaProtegida']);
Route::get('rutaverificado', [\App\Http\Controllers\PruebaController::class, 'rutaVerificado']);
Route::get('onlyroot', [\App\Http\Controllers\PruebaController::class, 'onlyroot']);
Route::get('profile', [\App\Http\Controllers\UserManagementController::class, 'profile'])->name('profile');
Route::get('root', [\App\Http\Controllers\UserManagementController::class, 'root'])->name('root');
Route::put('user/update', [\App\Http\Controllers\UserManagementController::class, 'update'])->name('user.update');
Route::put('user/password', [\App\Http\Controllers\UserManagementController::class, 'password'])->name('user.password');
//Route::get('user/admin', [\App\Http\Controllers\UserManagementController::class, 'admin'])->name('admin');
Route::resource('admin', \App\Http\Controllers\AdminController::class);
